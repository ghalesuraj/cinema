<?php the_excerpt(); ?>

