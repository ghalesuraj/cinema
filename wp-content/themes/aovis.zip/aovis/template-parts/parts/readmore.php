<a href="<?php the_permalink(); ?>" class="btn readmore">
	<?php  esc_html_e('Read more', 'aovis'); ?>
</a>


